import React, { useState, useCallback, useEffect, useContext, createContext, useRef } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { Router } from "wouter";
import { queryClient, setCrmBaseUrl, clearCrmBaseUrl } from "@/lib/queryClient";
import { CrmAuthenticatedRouter } from "@/CrmRouter";
import { CrmContext } from "@/CrmContext";

// ── Internal location context ──────────────────────────────────────────────
// HorsemanCRM owns the path state. The wouter hook reads it via this context,
// avoiding any hook-factory / rules-of-hooks issues.
const LocationCtx = createContext<{
  path: string;
  navigate: (to: string) => void;
}>({ path: "/", navigate: () => {} });

function useMemoryLocation(_opts?: { base?: string }): [string, (to: string | URL) => void] {
  const { path, navigate } = useContext(LocationCtx);
  const nav = useCallback(
    (to: string | URL) => navigate(typeof to === "string" ? to : (to.pathname ?? "/")),
    [navigate],
  );
  return [path, nav];
}

// ── Nav sections ───────────────────────────────────────────────────────────
export interface HorsemanNavItem { name: string; path: string; }
export interface HorsemanNavSection { label: string; items: HorsemanNavItem[]; }

export const HORSEMAN_NAV_SECTIONS: HorsemanNavSection[] = [
  {
    label: "Overview",
    items: [
      { name: "Dashboard", path: "/" },
      { name: "Reports",   path: "/reports" },
    ],
  },
  {
    label: "CRM",
    items: [
      { name: "Contacts",  path: "/contacts" },
      { name: "Companies", path: "/companies" },
      { name: "Deals",     path: "/deals" },
      { name: "Pipeline",  path: "/pipeline" },
    ],
  },
  {
    label: "Productivity",
    items: [
      { name: "Tasks",     path: "/tasks" },
      { name: "Emails",    path: "/emails" },
      { name: "Documents", path: "/documents" },
      { name: "Projects",  path: "/projects" },
    ],
  },
  {
    label: "Marketing",
    items: [
      { name: "Campaigns", path: "/campaigns" },
      { name: "Sequences", path: "/sequences" },
      { name: "Web Forms", path: "/forms" },
      { name: "Quotes",    path: "/quotes" },
    ],
  },
  {
    label: "System",
    items: [
      { name: "Automations", path: "/automations" },
      { name: "Audit Log",   path: "/audit-log" },
      { name: "Settings",    path: "/settings" },
    ],
  },
  {
    label: "Developers",
    items: [
      { name: "API Docs",      path: "/developers" },
      { name: "API Keys",      path: "/keys" },
      { name: "Webhooks",      path: "/webhooks" },
      { name: "Billing & Plan", path: "/billing" },
    ],
  },
];

// ── Props ──────────────────────────────────────────────────────────────────
export interface HorsemanCRMProps {
  baseUrl: string;
  ssoToken: string;
  /** Mount path prefix inside the host app's router. Defaults to "/". */
  basePath?: string;
  /**
   * Hide the Horseman sidebar so you can integrate CRM navigation directly
   * into your own app's sidebar. Pair with `path` + `onNavigate`.
   */
  hideSidebar?: boolean;
  /**
   * Controlled current path (e.g. "/contacts"). When provided the component
   * acts in controlled mode — update this prop in your `onNavigate` handler
   * to keep the CRM in sync with your sidebar's active state.
   */
  path?: string;
  /**
   * Called whenever the CRM navigates internally (e.g. clicking a contact
   * row opens /contacts/:id). Use this to sync your own sidebar active state.
   */
  onNavigate?: (path: string) => void;
  className?: string;
  style?: React.CSSProperties;
}

type AuthState = "loading" | "ready" | "error";

export function HorsemanCRM({
  baseUrl,
  ssoToken,
  basePath = "/",
  hideSidebar = false,
  path: controlledPath,
  onNavigate,
  className,
  style,
}: HorsemanCRMProps) {
  const [authState, setAuthState] = useState<AuthState>("loading");
  const [errorMessage, setErrorMessage] = useState("");
  const [internalPath, setInternalPath] = useState(controlledPath ?? "/");

  // Sync internal path when the controlled path prop changes from outside
  useEffect(() => {
    if (controlledPath !== undefined) {
      setInternalPath(controlledPath);
    }
  }, [controlledPath]);

  // Keep onNavigate ref fresh so navigate callback never goes stale
  const onNavigateRef = useRef(onNavigate);
  onNavigateRef.current = onNavigate;

  const navigate = useCallback((to: string) => {
    setInternalPath(to);
    onNavigateRef.current?.(to);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const base = baseUrl.replace(/\/+$/, "");

    setCrmBaseUrl(base);

    fetch(`${base}/api/auth/sso`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ token: ssoToken }),
    })
      .then(async (res) => {
        if (cancelled) return;
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          const msg = (body as { message?: string }).message ?? `SSO failed (${res.status})`;
          setErrorMessage(msg);
          setAuthState("error");
        } else {
          setAuthState("ready");
        }
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setErrorMessage(err instanceof Error ? err.message : "Network error during SSO");
          setAuthState("error");
        }
      });

    return () => {
      cancelled = true;
      clearCrmBaseUrl();
    };
  }, [baseUrl, ssoToken]);

  if (authState === "loading") {
    return (
      <div className={className} style={style}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: 200, color: "#9BA7B8", fontSize: 14 }}>
          Loading Horseman CRM…
        </div>
      </div>
    );
  }

  if (authState === "error") {
    return (
      <div className={className} style={style}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: 200, color: "#ef4444", fontSize: 14 }}>
          {errorMessage}
        </div>
      </div>
    );
  }

  return (
    <div className={`dark ${className ?? ""}`} style={{ overflow: "hidden", ...style }}>
      <CrmContext.Provider value={{ isEmbedded: true, hideSidebar }}>
        <QueryClientProvider client={queryClient}>
          <LocationCtx.Provider value={{ path: internalPath, navigate }}>
            <Router hook={useMemoryLocation} base={basePath}>
              <CrmAuthenticatedRouter />
            </Router>
          </LocationCtx.Provider>
        </QueryClientProvider>
      </CrmContext.Provider>
    </div>
  );
}
