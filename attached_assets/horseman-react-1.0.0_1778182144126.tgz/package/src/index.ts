export { HorsemanCRM } from "./HorsemanCRM";
export type { HorsemanCRMProps } from "./HorsemanCRM";
