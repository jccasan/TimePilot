import React, { useState, useCallback, useEffect } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { Router } from "wouter";
import { queryClient, setCrmBaseUrl, clearCrmBaseUrl } from "@/lib/queryClient";
import { CrmAuthenticatedRouter } from "@/CrmRouter";
import { CrmContext } from "@/CrmContext";

export interface HorsemanCRMProps {
  baseUrl: string;
  ssoToken: string;
  /** Mount path prefix inside the host app's router. Defaults to "/". */
  basePath?: string;
  className?: string;
  style?: React.CSSProperties;
}

// Memory-based location hook for wouter — keeps the embedded CRM's internal
// navigation completely isolated from the host app's browser URL / router.
// Typed to match wouter's UseLocationHook signature without any `as any` casts.
function useMemoryLocation(_opts?: { base?: string }): [string, (to: string | URL) => void] {
  const [path, setPath] = useState("/");
  const navigate = useCallback((to: string | URL) => {
    setPath(typeof to === "string" ? to : to.pathname ?? "/");
  }, []);
  return [path, navigate];
}

type AuthState = "loading" | "ready" | "error";

export function HorsemanCRM({
  baseUrl,
  ssoToken,
  basePath = "/",
  className,
  style,
}: HorsemanCRMProps) {
  const [authState, setAuthState] = useState<AuthState>("loading");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    let cancelled = false;
    const base = baseUrl.replace(/\/+$/, "");

    // Point all relative /api/* calls in the CRM pages to the remote instance.
    // Uses the module-level singleton from queryClient.ts so mutation
    // invalidations (which reference the same singleton directly) stay in sync
    // with the QueryClientProvider below.
    setCrmBaseUrl(base);

    fetch(`${base}/api/auth/sso`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ token: ssoToken }),
    })
      .then(async (res) => {
        if (cancelled) return;
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          const msg = (body as { message?: string }).message ?? `SSO failed (${res.status})`;
          setErrorMessage(msg);
          setAuthState("error");
        } else {
          setAuthState("ready");
        }
      })
      .catch((err: unknown) => {
        if (!cancelled) {
          setErrorMessage(err instanceof Error ? err.message : "Network error during SSO");
          setAuthState("error");
        }
      });

    return () => {
      cancelled = true;
      clearCrmBaseUrl();
    };
  }, [baseUrl, ssoToken]);

  if (authState === "loading") {
    return (
      <div className={className} style={style}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            minHeight: 200,
            color: "#9BA7B8",
            fontSize: 14,
          }}
        >
          Loading Horseman CRM…
        </div>
      </div>
    );
  }

  if (authState === "error") {
    return (
      <div className={className} style={style}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            minHeight: 200,
            color: "#ef4444",
            fontSize: 14,
          }}
        >
          {errorMessage}
        </div>
      </div>
    );
  }

  return (
    <div className={`dark ${className ?? ""}`} style={{ overflow: "hidden", ...style }}>
      {/* isEmbedded=true prevents Sidebar from toggling document.documentElement
          dark class or reading/writing localStorage theme, which would bleed
          into the host application's own theme state. */}
      <CrmContext.Provider value={{ isEmbedded: true }}>
        {/* Provide the shared singleton queryClient so direct imports of
            `queryClient` in CRM pages (for invalidation) match the provider. */}
        <QueryClientProvider client={queryClient}>
          <Router hook={useMemoryLocation} base={basePath}>
            <CrmAuthenticatedRouter />
          </Router>
        </QueryClientProvider>
      </CrmContext.Provider>
    </div>
  );
}
