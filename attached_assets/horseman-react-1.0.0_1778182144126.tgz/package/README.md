# @horseman/react

Embeddable React component for [Horseman CRM](https://github.com/horseman-crm). Drop the full CRM UI into any React or Next.js application with a single component. Authentication is handled silently via a short-lived SSO token — no separate login screen required.

## Installation

```bash
npm install @horseman/react @tanstack/react-query wouter
# or
pnpm add @horseman/react @tanstack/react-query wouter
```

## Quick start

### 1. Generate an SSO token on your server

First, get your tenant's SSO secret from **Settings → Embed & SSO** inside your Horseman dashboard.

```ts
// pages/api/horseman-token.ts  (Next.js API route)
import { generateSsoToken } from "@horseman/sdk";

export default function handler(req, res) {
  const token = generateSsoToken(process.env.HORSEMAN_SSO_SECRET!, {
    iss: "your-tenant-slug",   // the slug shown in your Horseman Settings
    email: req.user.email,
    firstName: req.user.firstName,
    lastName: req.user.lastName,
    role: "member",            // "admin" | "member" | "viewer"
    expiresInSeconds: 300,     // token is valid for 5 minutes
  });
  res.json({ token });
}
```

### 2. Mount `<HorsemanCRM />` in your page

```tsx
// pages/crm.tsx  (Next.js page)
import { HorsemanCRM } from "@horseman/react";

export async function getServerSideProps(ctx) {
  // Fetch a fresh SSO token for the current user
  const res = await fetch(`${process.env.APP_URL}/api/horseman-token`, {
    headers: { cookie: ctx.req.headers.cookie! },
  });
  const { token } = await res.json();
  return { props: { ssoToken: token } };
}

export default function CrmPage({ ssoToken }: { ssoToken: string }) {
  return (
    <HorsemanCRM
      baseUrl="https://your-horseman-instance.example.com"
      ssoToken={ssoToken}
      basePath="/crm"
      className="rounded-xl border border-slate-800 h-[800px]"
    />
  );
}
```

## Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `baseUrl` | `string` | Yes | Base URL of your Horseman CRM instance (no trailing slash) |
| `ssoToken` | `string` | Yes | Short-lived signed JWT minted with `generateSsoToken` |
| `basePath` | `string` | No | Router base path inside the host app (default: `"/"`) |
| `className` | `string` | No | CSS class added to the root wrapper element |

## Security notes

- **Always mint SSO tokens server-side** — never expose your `HORSEMAN_SSO_SECRET` to the browser.
- Tokens expire after `expiresInSeconds` (default 5 minutes). Regenerate them before mounting the component, e.g. via `getServerSideProps`.
- The `iss` claim must match your tenant's slug exactly — the server uses it to look up the correct signing secret.

## Rotating the SSO secret

Go to **Settings → Embed & SSO** in your Horseman dashboard and click **Rotate Secret**. Any previously issued tokens will immediately become invalid. Generate a new token with the new secret before remounting the component.

## Building from source

```bash
cd packages/horseman-react
pnpm install
pnpm build
```

This produces `dist/index.js` (ESM), `dist/index.cjs` (CJS), and `dist/index.d.ts` (TypeScript declarations).
